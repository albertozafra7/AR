geodesy.props
-------------

.. automodule:: geodesy.props
   :members:
