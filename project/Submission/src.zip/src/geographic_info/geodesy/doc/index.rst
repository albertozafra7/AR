.. geodesy documentation master file, created by
   sphinx-quickstart on Wed Apr 25 16:01:20 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

geodesy: Python APIs for Geographic coordinates
===============================================

Contents:

.. toctree::
   :maxdepth: 2
   :glob:

   geodesy.*
   CHANGELOG

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
