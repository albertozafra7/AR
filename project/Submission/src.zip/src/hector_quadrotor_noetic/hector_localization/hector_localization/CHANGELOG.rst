^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_localization
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.0 (2021-02-16)
------------------
* Update maintainer email address
* Increase minimum CMake version to 3.0.2 to avoid the CMP0048 warning
  See
  http://wiki.ros.org/noetic/Migration#Increase_required_CMake_version_to_avoid_author_warning
  for details.
* Contributors: Johannes Meyer

0.3.0 (2016-06-27)
------------------

0.2.2 (2016-06-24)
------------------

0.2.1 (2015-11-08)
------------------

0.2.0 (2015-02-22)
------------------

0.1.5 (2014-10-02)
------------------

0.1.4 (2014-08-28)
------------------
* Removed package world_magnetic_model as it is currently not used by hector_pose_estimation
  The package is still available in the world_magnetic_model branch.
* Contributors: Johannes Meyer

0.1.3 (2014-07-09)
------------------

0.1.2 (2014-06-02)
------------------

0.1.1 (2014-03-30)
------------------
* made hector_localization a true metapackage
* Contributors: Johannes Meyer

0.1.0 (2013-09-03)
------------------
* catkinized stack hector_localization
