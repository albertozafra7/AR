unique_identifier
=================

ROS messages and interfaces for Universally Unique Identifiers.

 * http://en.wikipedia.org/wiki/Uuid
 * http://tools.ietf.org/html/rfc4122.html

ROS documentation:

 * http://www.ros.org/wiki/unique_id
 * http://www.ros.org/wiki/unique_identifier
 * http://www.ros.org/wiki/uuid_msgs
