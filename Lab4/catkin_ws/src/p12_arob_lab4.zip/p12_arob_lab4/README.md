# p12_arob_lab4
Laboratory class 4: ROS Navigation
